/**
 * @file    memcpyLink.h
 * @author  Chirag Jain <cjain7@gatech.edu>
 */


__asm__(".symver memcpy,memcpy@GLIBC_2.2.5");

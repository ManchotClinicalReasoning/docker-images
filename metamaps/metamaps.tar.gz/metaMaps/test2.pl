print (-e 'downloads/refseq/archaea/Methanothermococcus_thermolithotrophicus/GCF_000376965.1_ASM37696v1/GCF_000376965.1_ASM37696v1_genomic.fna.gz');
